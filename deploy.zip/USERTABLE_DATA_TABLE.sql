REM INSERTING into ORACLE1.USERTABLE
SET DEFINE OFF;
Insert into ORACLE1.USERTABLE (USERNAME,PASSWORD,ADDRESS,EMAILID,PHONE_NO,ACCOUNT_NO,DATE_OF_BIRTH,GENDER,PAN_NUMBER) values ('erftghj','dfghj','dfgh','fghj','fghj','dfgh','dfghj','9876543','female');
Insert into ORACLE1.USERTABLE (USERNAME,PASSWORD,ADDRESS,EMAILID,PHONE_NO,ACCOUNT_NO,DATE_OF_BIRTH,GENDER,PAN_NUMBER) values ('cjgtfvk','fgh','fghj','rfghj','rfghj','dfghj','dfghjk','dfgh','female');
